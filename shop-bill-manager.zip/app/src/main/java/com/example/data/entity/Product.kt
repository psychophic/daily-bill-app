package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val price: Double,
    val iconKey: String, // "sports", "smoking", "tea", "coffee", "food", "drink", "cake", "cart"
    val quantity: Int = 0, // transient count selected on Dashboard
    val isDefault: Boolean = false
)
