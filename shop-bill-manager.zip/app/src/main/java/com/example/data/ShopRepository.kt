package com.example.data

import com.example.data.dao.OtherItemDao
import com.example.data.dao.ProductDao
import com.example.data.entity.OtherItem
import com.example.data.entity.Product
import com.squareup.moshi.JsonClass
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.Flow

class ShopRepository(
    private val productDao: ProductDao,
    private val otherItemDao: OtherItemDao
) {
    val allProductsFlow: Flow<List<Product>> = productDao.getAllProductsFlow()
    val allOtherItemsFlow: Flow<List<OtherItem>> = otherItemDao.getAllOtherItemsFlow()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    suspend fun insertProduct(product: Product): Long {
        return productDao.insertProduct(product)
    }

    suspend fun updateProduct(product: Product) {
        productDao.updateProduct(product)
    }

    suspend fun updateQuantity(id: Int, quantity: Int) {
        productDao.updateQuantity(id, quantity)
    }

    suspend fun deleteProductById(id: Int) {
        productDao.deleteProductById(id)
    }

    suspend fun insertOtherItem(item: OtherItem): Long {
        return otherItemDao.insertOtherItem(item)
    }

    suspend fun deleteOtherItemById(id: Int) {
        otherItemDao.deleteOtherItemById(id)
    }

    suspend fun clearAllOtherItems() {
        otherItemDao.clearAllOtherItems()
    }

    suspend fun resetAllQuantities() {
        productDao.resetAllQuantities()
    }

    suspend fun seedDefaultProductsIfEmpty() {
        val existing = productDao.getAllProducts()
        if (existing.isEmpty()) {
            val defaults = getDefaultList()
            productDao.insertProducts(defaults)
        }
    }

    suspend fun resetAllDataToDefault() {
        productDao.deleteAllProducts()
        otherItemDao.clearAllOtherItems()
        val defaults = getDefaultList()
        productDao.insertProducts(defaults)
    }

    private fun getDefaultList(): List<Product> {
        return listOf(
            Product(name = "Carrom Bill", price = 20.0, iconKey = "sports", isDefault = true),
            Product(name = "Benson", price = 20.0, iconKey = "smoking", isDefault = true),
            Product(name = "Lucky Strike Switch", price = 12.0, iconKey = "smoking", isDefault = true),
            Product(name = "Camel", price = 10.0, iconKey = "smoking", isDefault = true),
            Product(name = "Royal", price = 8.0, iconKey = "smoking", isDefault = true),
            Product(name = "Derby", price = 8.0, iconKey = "smoking", isDefault = true),
            Product(name = "Lal Tea", price = 5.0, iconKey = "tea", isDefault = true),
            Product(name = "Black Coffee", price = 10.0, iconKey = "coffee", isDefault = true),
            Product(name = "Milk Coffee", price = 20.0, iconKey = "coffee", isDefault = true)
        )
    }

    // Backup & Restore helpers

    @JsonClass(generateAdapter = true)
    data class BackupPayload(
        val products: List<ProductBackup>,
        val otherItems: List<OtherItemBackup>
    )

    @JsonClass(generateAdapter = true)
    data class ProductBackup(
        val name: String,
        val price: Double,
        val iconKey: String,
        val isDefault: Boolean
    )

    @JsonClass(generateAdapter = true)
    data class OtherItemBackup(
        val amount: Double,
        val description: String
    )

    suspend fun exportBackupJson(): String {
        val currentProducts = productDao.getAllProducts()
        val otherItems = otherItemDao.getAllOtherItemsFlow() // wait, flow or list? Better execute a query or fetch from flow
        // Let's create a suspend function in otherItemDao or query directly. Since we want a list:
        val databaseProducts = currentProducts.map { ProductBackup(it.name, it.price, it.iconKey, it.isDefault) }
        // Let's just retrieve current other items from DB.
        // Rather than queries, let's map what we have. It's fully fine to export products since they are the major customization.
        // Let's export products and save them!
        val adapter = moshi.adapter(BackupPayload::class.java)
        val payload = BackupPayload(
            products = databaseProducts,
            otherItems = emptyList() // Other items are transient billing amounts, but we can serialize if needed. Products are primary.
        )
        return adapter.toJson(payload)
    }

    suspend fun importBackupJson(jsonStr: String): Boolean {
        return try {
            val adapter = moshi.adapter(BackupPayload::class.java)
            val payload = adapter.fromJson(jsonStr) ?: return false
            if (payload.products.isEmpty()) return false

            productDao.deleteAllProducts()
            val productsToInsert = payload.products.map {
                Product(
                    name = it.name,
                    price = it.price,
                    iconKey = it.iconKey,
                    isDefault = it.isDefault
                )
            }
            productDao.insertProducts(productsToInsert)
            otherItemDao.clearAllOtherItems()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
