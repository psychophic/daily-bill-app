package com.example.data.dao

import androidx.room.*
import com.example.data.entity.OtherItem
import kotlinx.coroutines.flow.Flow

@Dao
interface OtherItemDao {
    @Query("SELECT * FROM other_items ORDER BY id DESC")
    fun getAllOtherItemsFlow(): Flow<List<OtherItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOtherItem(item: OtherItem): Long

    @Delete
    suspend fun deleteOtherItem(item: OtherItem)

    @Query("DELETE FROM other_items WHERE id = :id")
    suspend fun deleteOtherItemById(id: Int)

    @Query("DELETE FROM other_items")
    suspend fun clearAllOtherItems()
}
