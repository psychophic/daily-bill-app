package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.OtherItemDao
import com.example.data.dao.ProductDao
import com.example.data.entity.OtherItem
import com.example.data.entity.Product

@Database(entities = [Product::class, OtherItem::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun otherItemDao(): OtherItemDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shop_bill_manager_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
