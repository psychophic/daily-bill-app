package com.example.ui

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

data class IconOption(
    val key: String,
    val displayName: String,
    val icon: ImageVector
)

object IconMapper {
    val options = listOf(
        IconOption("smoking", "Smoking/Tobacco", Icons.Default.SmokingRooms),
        IconOption("tea", "Tea Cup", Icons.Default.LocalCafe),
        IconOption("coffee", "Coffee Cup", Icons.Default.Coffee),
        IconOption("sports", "Sports Esport/Carrom", Icons.Default.SportsEsports),
        IconOption("food", "Fast Food/Snacks", Icons.Default.Fastfood),
        IconOption("drink", "Cold Drink", Icons.Default.LocalBar),
        IconOption("cake", "Cake/Biscuit", Icons.Default.Cake),
        IconOption("cart", "General Cart / Product", Icons.Default.ShoppingCart)
    )

    fun getIconByKey(key: String): ImageVector {
        return options.find { it.key == key }?.icon ?: Icons.Default.ShoppingCart
    }
}
