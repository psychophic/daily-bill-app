package com.example.ui

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ShopRepository
import com.example.data.entity.OtherItem
import com.example.data.entity.Product
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShopViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = ShopRepository(db.productDao(), db.otherItemDao())

    val products: StateFlow<List<Product>> = repository.allProductsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val otherItems: StateFlow<List<OtherItem>> = repository.allOtherItemsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val prefs = application.getSharedPreferences("shop_bill_manager_prefs", Context.MODE_PRIVATE)
    private val _isDarkMode = MutableStateFlow(prefs.getBoolean("dark_mode", false))
    val isDarkMode: StateFlow<Boolean> = _isDarkMode.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedDefaultProductsIfEmpty()
        }
    }

    fun toggleDarkMode() {
        val newValue = !_isDarkMode.value
        prefs.edit().putBoolean("dark_mode", newValue).apply()
        _isDarkMode.value = newValue
    }

    fun incrementQuantity(product: Product) {
        viewModelScope.launch {
            repository.updateQuantity(product.id, product.quantity + 1)
        }
    }

    fun decrementQuantity(product: Product) {
        if (product.quantity > 0) {
            viewModelScope.launch {
                repository.updateQuantity(product.id, product.quantity - 1)
            }
        }
    }

    fun updateProductQuantity(product: Product, quantity: Int) {
        if (quantity >= 0) {
            viewModelScope.launch {
                repository.updateQuantity(product.id, quantity)
            }
        }
    }

    fun addCustomProductDirectly(name: String, price: Double, quantity: Int, iconKey: String) {
        viewModelScope.launch {
            repository.insertProduct(
                Product(
                    name = name,
                    price = price,
                    iconKey = iconKey,
                    quantity = quantity,
                    isDefault = false
                )
            )
        }
    }

    fun addOtherItem(amount: Double, description: String = "") {
        viewModelScope.launch {
            repository.insertOtherItem(OtherItem(amount = amount, description = description))
        }
    }

    fun deleteOtherItem(item: OtherItem) {
        viewModelScope.launch {
            repository.deleteOtherItemById(item.id)
        }
    }

    fun clearOtherItems() {
        viewModelScope.launch {
            repository.clearAllOtherItems()
        }
    }

    fun resetQuantitiesAndOtherItems() {
        viewModelScope.launch {
            repository.resetAllQuantities()
            repository.clearAllOtherItems()
        }
    }

    // CRUD for Products page

    fun addNewProduct(name: String, price: Double, iconKey: String) {
        viewModelScope.launch {
            repository.insertProduct(
                Product(
                    name = name,
                    price = price,
                    iconKey = iconKey,
                    quantity = 0,
                    isDefault = false
                )
            )
        }
    }

    fun updateProductDetails(product: Product, name: String, price: Double, iconKey: String) {
        viewModelScope.launch {
            repository.updateProduct(
                product.copy(name = name, price = price, iconKey = iconKey)
            )
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProductById(product.id)
        }
    }

    fun resetAllData() {
        viewModelScope.launch {
            repository.resetAllDataToDefault()
        }
    }

    // Backup & Restore via Clipboard / JSON string

    fun copyBackupToClipboard(context: Context) {
        viewModelScope.launch {
            try {
                val jsonStr = repository.exportBackupJson()
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = ClipData.newPlainText("Shop Bill Manager Backup", jsonStr)
                clipboard.setPrimaryClip(clip)
                Toast.makeText(context, "Backup copied to clipboard! Save it safely.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to create backup: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun restoreFromBackupText(context: Context, backupText: String) {
        viewModelScope.launch {
            val success = repository.importBackupJson(backupText)
            if (success) {
                Toast.makeText(context, "Data restoration successful!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Invalid backup data! Please check and try again.", Toast.LENGTH_LONG).show()
            }
        }
    }
}
