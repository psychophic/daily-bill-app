package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.entity.OtherItem
import com.example.data.entity.Product
import com.example.ui.IconMapper
import com.example.ui.ShopViewModel

@OptIn(ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    viewModel: ShopViewModel,
    onNavigateToSummary: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val products by viewModel.products.collectAsState()
    val otherItems by viewModel.otherItems.collectAsState()

    // Form states for Custom Product Entry
    var customName by remember { mutableStateOf("") }
    var customPrice by remember { mutableStateOf("") }
    var customQty by remember { mutableStateOf("1") }
    var customSelectedIconKey by remember { mutableStateOf("cart") }
    var showIconDropdown by remember { mutableStateOf(false) }

    // Form state for Other Items
    var otherAmountInput by remember { mutableStateOf("") }

    // State for tapping a quantity to set manually via input dialog
    var productToSetQuantityManually by remember { mutableStateOf<Product?>(null) }
    var manualQuantityInput by remember { mutableStateOf("") }

    // Derived values
    val totalBillProducts = products.sumOf { it.price * it.quantity }
    val totalBillOthers = otherItems.sumOf { it.amount }
    val grandTotalBill = totalBillProducts + totalBillOthers

    Box(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen_root")
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Card / Quick Status
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "CURRENT BILL ACTIVE",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "৳ ${"%,.2f".format(grandTotalBill)}",
                            style = MaterialTheme.typography.headlineLarge.copy(fontSize = 38.sp),
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Items: ${products.sumOf { it.quantity }}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Box(
                                modifier = Modifier
                                    .size(4.dp)
                                    .background(
                                        MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.5f),
                                        RoundedCornerShape(50)
                                    )
                            )
                            Text(
                                text = "Others: ৳${"%.0f".format(totalBillOthers)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                }
            }

            // SECTION label: PRODUCTS
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Select Products",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (products.any { it.quantity > 0 } || otherItems.isNotEmpty()) {
                        TextButton(
                            onClick = {
                                viewModel.resetQuantitiesAndOtherItems()
                                Toast.makeText(context, "Bill Reset Completed", Toast.LENGTH_SHORT).show()
                            },
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reset All", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Reset", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }

            // Products Grid/List (Beautiful modern cards with ripple and quantity selector)
            items(products, key = { it.id }) { product ->
                val isActive = product.quantity > 0
                val activeBorderModifier = if (isActive) {
                    Modifier.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(16.dp))
                } else Modifier

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .then(activeBorderModifier)
                        .clip(RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isActive) MaterialTheme.colorScheme.surfaceColorAtElevation(4.dp)
                        else MaterialTheme.colorScheme.surface
                    ),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = if (isActive) 4.dp else 1.dp
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Product Icon & Decoration
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (isActive) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                    else MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = IconMapper.getIconByKey(product.iconKey),
                                contentDescription = product.name,
                                tint = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        // Product Name / Price
                        Column(
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = product.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontSize = 17.sp),
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "৳ ${product.price}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        // Quantity Selector Section
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Decrement
                            IconButton(
                                onClick = { viewModel.decrementQuantity(product) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.secondaryContainer),
                                colors = IconButtonDefaults.iconButtonColors(
                                    contentColor = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(18.dp))
                            }

                            // Editable quantity via long press or click!
                            Box(
                                modifier = Modifier
                                    .widthIn(min = 34.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .combinedClickable(
                                        onClick = {
                                            productToSetQuantityManually = product
                                            manualQuantityInput = product.quantity.toString()
                                        },
                                        onLongClick = {
                                            productToSetQuantityManually = product
                                            manualQuantityInput = product.quantity.toString()
                                        }
                                    )
                                    .padding(vertical = 4.dp, horizontal = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = product.quantity.toString(),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            }

                            // Increment
                            IconButton(
                                onClick = { viewModel.incrementQuantity(product) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.primary),
                                colors = IconButtonDefaults.iconButtonColors(
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            // Quick Other Items Added Section
            if (otherItems.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Quick Added Other Items",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                item {
                    FlowRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        otherItems.forEach { item ->
                            InputChip(
                                selected = true,
                                onClick = {},
                                label = {
                                    Text(
                                        text = if (item.description.isNotEmpty()) "${item.description}: ৳${item.amount}" else "Other ৳${item.amount}",
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                },
                                trailingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Remove expense",
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clickable { viewModel.deleteOtherItem(item) }
                                    )
                                },
                                colors = InputChipDefaults.inputChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.tertiaryContainer,
                                    selectedLabelColor = MaterialTheme.colorScheme.onTertiaryContainer
                                ),
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }
            }

            // Section label: ADD EXTRAS (OTHER ITEMS + CUSTOM PRODUCT ENTRY)
            item {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(10.dp))
            }

            // COMBINED QUICK EXTRAS CARD
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Header
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.AddBox,
                                contentDescription = "Add Extras",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Other Items/Quick Expense",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Input field for single quick amount
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedTextField(
                                value = otherAmountInput,
                                onValueChange = { otherAmountInput = it },
                                label = { Text("Amount (৳)") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                prefix = { Text("৳ ") },
                                singleLine = true
                            )

                            Button(
                                onClick = {
                                    val amount = otherAmountInput.toDoubleOrNull()
                                    if (amount != null && amount > 0) {
                                        viewModel.addOtherItem(amount, "")
                                        otherAmountInput = ""
                                        Toast.makeText(context, "Added Other Item", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Enter a valid amount!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
                                modifier = Modifier.align(Alignment.CenterVertically)
                            ) {
                                Text("Add")
                            }
                        }
                    }
                }
            }

            // ADD CUSTOM PRODUCT CARD
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.PlaylistAdd,
                                contentDescription = "Add Product",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Add Custom Product",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        // Name
                        OutlinedTextField(
                            value = customName,
                            onValueChange = { customName = it },
                            label = { Text("Product Name") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            // Price
                            OutlinedTextField(
                                value = customPrice,
                                onValueChange = { customPrice = it },
                                label = { Text("Price") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1.2f),
                                prefix = { Text("৳ ") },
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )

                            // Initial Quantity
                            OutlinedTextField(
                                value = customQty,
                                onValueChange = { customQty = it },
                                label = { Text("Qty") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(0.8f),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                        }

                        // Icon Selector
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    1.dp,
                                    MaterialTheme.colorScheme.outline,
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { showIconDropdown = true }
                                .padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = IconMapper.getIconByKey(customSelectedIconKey),
                                    contentDescription = "Selected Icon",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = IconMapper.options.find { it.key == customSelectedIconKey }?.displayName ?: "Select Icon",
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                        }

                        if (showIconDropdown) {
                            Dialog(onDismissRequest = { showIconDropdown = false }) {
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(16.dp),
                                    shape = RoundedCornerShape(20.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp)
                                    ) {
                                        Text(
                                            text = "Choose Product Icon",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(bottom = 12.dp)
                                        )

                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            IconMapper.options.chunked(2).forEach { rowKeys ->
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    rowKeys.forEach { item ->
                                                        val isSelected = customSelectedIconKey == item.key
                                                        Box(
                                                            modifier = Modifier
                                                                .weight(1f)
                                                                .clip(RoundedCornerShape(10.dp))
                                                                .background(
                                                                    if (isSelected) MaterialTheme.colorScheme.primaryContainer
                                                                    else MaterialTheme.colorScheme.surface
                                                                )
                                                                .border(
                                                                    1.dp,
                                                                    if (isSelected) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.3f),
                                                                    RoundedCornerShape(10.dp)
                                                                )
                                                                .clickable {
                                                                    customSelectedIconKey = item.key
                                                                    showIconDropdown = false
                                                                }
                                                                .padding(12.dp),
                                                            contentAlignment = Alignment.CenterStart
                                                        ) {
                                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                                Icon(
                                                                    imageVector = item.icon,
                                                                    contentDescription = item.displayName,
                                                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                                    modifier = Modifier.size(20.dp)
                                                                )
                                                                Spacer(modifier = Modifier.width(8.dp))
                                                                Text(
                                                                    text = item.displayName,
                                                                    style = MaterialTheme.typography.bodySmall,
                                                                    fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // Save Product button
                        Button(
                            onClick = {
                                if (customName.trim().isEmpty()) {
                                    Toast.makeText(context, "Enter product name!", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val price = customPrice.toDoubleOrNull()
                                if (price == null || price <= 0) {
                                    Toast.makeText(context, "Enter clear valid price!", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                val qty = customQty.toIntOrNull() ?: 1
                                if (qty < 0) {
                                    Toast.makeText(context, "Enter valid quantity!", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }

                                viewModel.addCustomProductDirectly(customName, price, qty, customSelectedIconKey)
                                // reset fields
                                customName = ""
                                customPrice = ""
                                customQty = "1"
                                customSelectedIconKey = "cart"
                                Toast.makeText(context, "Custom Product Added to Bill", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = "Add")
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Custom Product")
                        }
                    }
                }
            }
        }

        // Floating "Calculate Total Bill" full-width container at the bottom
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color.Transparent, MaterialTheme.colorScheme.background.copy(alpha = 0.95f))
                    )
                )
                .padding(16.dp)
        ) {
            val totalQtyOrdered = products.sumOf { it.quantity }
            val hasActiveBill = totalQtyOrdered > 0 || otherItems.isNotEmpty()

            Button(
                onClick = {
                    if (hasActiveBill) {
                        onNavigateToSummary()
                    } else {
                        Toast.makeText(context, "Cart is currently empty! Add something to calculate.", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("calculate_bill_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (hasActiveBill) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary.copy(alpha = 0.5f)
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 6.dp)
            ) {
                Icon(Icons.Default.Calculate, contentDescription = "Calculate", modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Calculate Total Bill (৳${"%,.0f".format(grandTotalBill)})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    // Modal dialog to set quantities manually (allows speedy editing of large numbers)
    productToSetQuantityManually?.let { product ->
        AlertDialog(
            onDismissRequest = { productToSetQuantityManually = null },
            title = { Text("Set Quantity for ${product.name}") },
            text = {
                OutlinedTextField(
                    value = manualQuantityInput,
                    onValueChange = { manualQuantityInput = it },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text("Enter quantity") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val qty = manualQuantityInput.trim().toIntOrNull()
                        if (qty != null && qty >= 0) {
                            viewModel.updateProductQuantity(product, qty)
                            productToSetQuantityManually = null
                        } else {
                            Toast.makeText(context, "Enter a valid positive number!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { productToSetQuantityManually = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}
