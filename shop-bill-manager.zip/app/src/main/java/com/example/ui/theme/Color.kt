package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm Caffé & Copper Palette (for rich, premium tea stall & tobacco club vibe)
val WarmCopperLight = Color(0xFFD84315) // Deep Tea Copper
val CoffeeBrownLight = Color(0xFF5D4037) // Rich Espresso Brown
val MintTealLight = Color(0xFF00796B) // Clean Slate Teal

val OffWhiteBg = Color(0xFFFAF8F6) // Warm paper background
val CardWarmBg = Color(0xFFFFFFFF) // Clean card
val TextDarkPrimary = Color(0xFF2D201C) // Charcoal Brown text

// Dark Mode - Deep Charcoal & Amber embers
val WarmAmberDark = Color(0xFFFF8A65) // Soft glowing copper
val CreamEspressoDark = Color(0xFFD7CCC8) // Milk coffee cream
val SoftTealDark = Color(0xFF4DB6AC) // Mint tea teal

val DeepCharcoalBg = Color(0xFF120E0C) // Very dark ambient slate brown
val CardCharcoalBg = Color(0xFF1E1715) // Slightly lighter card container
val TextLightPrimary = Color(0xFFF5EBE6) // Soft milk white text
