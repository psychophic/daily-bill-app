package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = WarmAmberDark,
    secondary = CreamEspressoDark,
    tertiary = SoftTealDark,
    background = DeepCharcoalBg,
    surface = CardCharcoalBg,
    onPrimary = TextDarkPrimary,
    onSecondary = TextDarkPrimary,
    onTertiary = TextDarkPrimary,
    onBackground = TextLightPrimary,
    onSurface = TextLightPrimary,
    error = androidx.compose.ui.graphics.Color(0xFFEF9A9A),
    onError = TextDarkPrimary,
    surfaceVariant = DeepCharcoalBg
)

private val LightColorScheme = lightColorScheme(
    primary = WarmCopperLight,
    secondary = CoffeeBrownLight,
    tertiary = MintTealLight,
    background = OffWhiteBg,
    surface = CardWarmBg,
    onPrimary = androidx.compose.ui.graphics.Color.White,
    onSecondary = androidx.compose.ui.graphics.Color.White,
    onTertiary = androidx.compose.ui.graphics.Color.White,
    onBackground = TextDarkPrimary,
    onSurface = TextDarkPrimary,
    error = androidx.compose.ui.graphics.Color(0xFFB71C1C),
    onError = androidx.compose.ui.graphics.Color.White,
    surfaceVariant = OffWhiteBg
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
